from pathlib import Path

repertoire = Path() / 'data' / 'fichiers'
fichier = repertoire / 'monfichier.txt'

ligne_a_ecrire = ['Ligne1\n', 'Ligne2\n', 'Ligne3\n']

# On vérifie que l'arborescence de répertoire existe, dans le cas contraire on la créée
if not repertoire.is_dir():
    repertoire.mkdir(parents=True)

#
# 1. Ecrire les lignes dans le fichier
#
with fichier.open('w') as f:            # On utilise la méthode open() de pathlib !
    f.writelines(ligne_a_ecrire)

#
# 2. Lire les lignes depuis le fichier
#
with fichier.open('r') as f:
    lignes_lues = f.readlines()
    for ln in lignes_lues:
        print(ln, end='') # end='' permet d'éviter de générer un saut de ligne supplémentaire.