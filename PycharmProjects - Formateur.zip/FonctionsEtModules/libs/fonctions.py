# Déclaration de la fonction
def dire_bonjour(prenom, nom=""):
    # print("Bonjour {} {} !".format(prenom, nom))
    message = "Bonjour {} {} !".format(prenom, nom)
    # On renvoi la valeur
    return message


def fonction_etoilee(*valeurs):
    print(valeurs)

