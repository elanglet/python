# Le nom du module est 'libs.calculatrice'

def addition(a, b):
    return a + b

def soustraction(a, b):
    return a - b

def multiplication(a, b):
    return a * b

def division(a, b):
    if b != 0:
        return a / b
    else:
        print("Division par zéro impossible !")

def moyenne(*notes):
    if len(notes) > 0:
        return sum(notes) / len(notes)
    else:
        print("Vous devez fournir des valeurs pour calculer la moyenne !")
