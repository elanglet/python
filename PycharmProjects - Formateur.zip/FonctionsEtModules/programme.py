from libs import fonctions

# Pseudo-main Python !
if __name__ == "__main__":
    # Appel de la fonction
    resultat = fonctions.dire_bonjour("Robert", "DUPONT")
    print("La fonction a produit le message : {}".format(resultat))

    resultat = fonctions.dire_bonjour("Etienne")
    print("La fonction a produit le message : {}".format(resultat))


    fonctions.fonction_etoilee("un", "deux", "trois")

    print(" *** Paramètres nommés *** ")
    resultat = fonctions.dire_bonjour(nom="DURAND", prenom="Michel")
    print("Avec les paramètres nommés : {}".format(resultat))
