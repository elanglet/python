from libs.fonctions import dire_bonjour, fonction_etoilee

#
# ou :
#      from fonctions import dire_bonjour
#      from fonctions import fonction_etoilee
#

if __name__ == "__main__":

    # Appel de la fonction
    resultat = dire_bonjour("Robert", "DUPONT")
    print("La fonction a produit le message : {}".format(resultat))

    resultat = dire_bonjour("Etienne")
    print("La fonction a produit le message : {}".format(resultat))


    fonction_etoilee("un", "deux", "trois")

    print(" *** Paramètres nommés *** ")
    resultat = dire_bonjour(nom="DURAND", prenom="Michel")
    print("Avec les paramètres nommés : {}".format(resultat))
