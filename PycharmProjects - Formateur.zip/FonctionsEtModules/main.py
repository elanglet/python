from libs.calculatrice import addition, soustraction, multiplication, division, moyenne

if __name__ == "__main__":

    print("Addition de 7 et 9 = {}".format(addition(7, 9)))
    print("Addition de 13 et 5 = {}".format(soustraction(13, 5)))
    print("Multiplication de 7 et 9 = {}".format(multiplication(7, 9)))

    resultat = division(55, 5)
    if resultat is not None:
        print("Division de 55 par 5 = {}".format(resultat))

    moy = moyenne(56, 23, 57, 12, 34)
    print("Moyenne des valeurs = {}".format(moy))


