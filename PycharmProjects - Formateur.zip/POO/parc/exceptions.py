# Module permettant de définir les classes d'exceptions utilisateur.

# Classe de base de toutes les exceptions utilisateur de ce projet.
# On hérite de la classe Exception du langage.
class VehiculeException(Exception):
    # Le mot clé pass sert à signifier qu'il n'y a rien a mettre dans ce bloc.
    pass

class VitesseException(VehiculeException):
    pass

class CarburantException(VehiculeException):
    pass

