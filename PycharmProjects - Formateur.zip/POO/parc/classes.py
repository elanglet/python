from parc.exceptions import VitesseException, CarburantException, VehiculeException


class Vehicule:

    # Déclaration des attributs.
    __marque = ""
    __modele = ""
    __vitesse = 0
    __vitesse_max = 0

    # Définition d'un constructeur pour initialiser les attributs des objets
    def __init__(self, marque, modele, vitesse, vitesse_max):
        # On initialise les attributs avec les valeurs reçues par les paramètres
        self.__marque = marque
        self.__modele = modele
        # On controle la cohérence des paramètres...
        if 0 <= vitesse <= vitesse_max:
            self.__vitesse = vitesse
        else:
            # On produit une exception
            # 1. Créer l'objet d'exception
            e = VitesseException("Valeur de vitesse incohérente !")
            # 2. Déclencher l'exception
            raise e

        if vitesse_max >= 0:
            self.__vitesse_max = vitesse_max
        else:
            raise VitesseException("La vitesse maximum doit être une valeur positive !")

    # Définition des méthodes
    #  -> Comme des fonctions mais avec un premier paramètre nommé 'self'
    def accelerer(self):
        if self.__vitesse < self.__vitesse_max:
            self.__vitesse += 1
        else:
            raise VitesseException("Vous êtes à fond !")

    def freiner(self):
        if self.__vitesse > 0:
            self.__vitesse -= 1
        else:
            raise VitesseException("Véhicule à l'arrêt.")

    # Accesseurs en lecture et en écriture
    def get_marque(self):
        return self.__marque

    def get_modele(self):
        return self.__modele

    def get_vitesse(self):
        return self.__vitesse

    def get_vitesse_max(self):
        return self.__vitesse_max

    def set_vitesse_max(self, vitesse_max):
        # La nouvelle valeur de vitesse_max ne peut être supérieur à la valeur actuelle !
        if vitesse_max <= self.__vitesse_max:
            self.__vitesse_max = vitesse_max
        else:
            raise VitesseException("La nouvelle valeur de vitesse maximum ne peut être supérieure à l'ancienne.")

    # Redéfinition de la méthode __eq__ pour permettre de comparer deux objets Vehicule avec ==
    def __eq__(self, other):
        # Il faut toujours commencer par vérifier que other est bien du type de la classe
        if isinstance(other, Vehicule) \
                and self.__marque == other.__marque \
                and self.__modele == other.__modele \
                and self.__vitesse == other.__vitesse \
                and self.__vitesse_max == other.__vitesse_max:

            return True
        return False


# La classe Voiture hérite de Vehicule
class Voiture(Vehicule):

    # Attributs qui s'ajoutent à ceux hérités
    __qte_carburant = 0
    __qte_carburant_max = 0
    __nombre_places = 0

    # Attribut référencant le contenu (Moteur)
    __moteur = None

    # On redéfinit un constructeur pour Voiture afin d'initialiser tous les attributs.
    # On spécifie un paramètre supplémentaire pour initialiser le moteur qui sera instancié dans le constructeur
    def __init__(self, marque, modele, vitesse, vitesse_max, qte_carburant, qte_carburant_max, nombre_places, energie):
        # On appelle le constructeur de Vehicule !
        # ATTENTION : Dans ce cas, il faut passer le paramètre self !!!
        Vehicule.__init__(self, marque, modele, vitesse, vitesse_max)

        # On initialise les attributs de Voiture
        if 0 <= qte_carburant <= qte_carburant_max:
            self.__qte_carburant = qte_carburant
        else:
            raise CarburantException("La quantité de carburant est incohérente.")

        if qte_carburant_max >= 0:
            self.__qte_carburant_max = qte_carburant_max
        else:
            raise CarburantException("La quantité de carburant maximum doit être une valeur positive.")

        if nombre_places > 0:
            self.__nombre_places = nombre_places
        else:
            raise CarburantException("Le nombre de places doit être une valeur positive.")

        # On créé le moteur en même temps que la voiture ! (Relation de composition)
        self.__moteur = Moteur(energie)

    # Méthodes qui s'ajoutent à celles héritées
    def faire_le_plein(self):
        self.__qte_carburant = self.__qte_carburant_max

    def get_qte_carburant(self):
        return self.__qte_carburant

    def get_qte_carburant_max(self):
        return self.__qte_carburant_max

    def get_nombre_places(self):
        return self.__nombre_places

    # Permet de récupérer une référence à l'objet Moteur contenu dans l'objet Voiture
    def get_moteur(self):
        return self.__moteur

    # Redéfinition de la méthode accelerer()
    # On doit prendre en compte la notion de carburant !
    def accelerer(self):
        if self.__qte_carburant > 0:
            # On appelle la méthode accelerer() de la super-classe (Vehicule)
            # ATTENTION : Il faut passer le paramètre self !
            Vehicule.accelerer(self)
            # On consomme du carburant...
            self.__qte_carburant -= 1
        else:
            raise CarburantException("Plus de carburant...")

    def __eq__(self, other):
        # On appelle la super-méthode, on vérifie que other est une Voiture, puis on compare les attributs.
        if Vehicule.__eq__(self, other) \
                and isinstance(other, Voiture) \
                and self.__qte_carburant == other.__qte_carburant \
                and self.__qte_carburant_max == other.__qte_carburant_max \
                and self.__nombre_places == other.__nombre_places \
                and self.get_moteur().get_energie() == other.get_moteur().get_energie():
            return True
        return False


class Velo(Vehicule):

    __type = ""

    def __init__(self, marque, modele, vitesse, vitesse_max, type):
        Vehicule.__init__(self, marque, modele, vitesse, vitesse_max)

        # Controles sur le type de velo
        # if type == "VTT" or type == "VTC" or type == "Course":

        # On vérifie si 'type' appartient à l'ensemble des valeurs
        if type in ("VTT", "VTC", "Course"):
            self.__type = type
        else:
            raise VehiculeException("Le type de vélo est invalide.")

    def get_type(self):
        return self.__type


    # On redéfinit la méthode accelerer()
    # Les vélos de course accélèrent de 2km/h, les autres de 1km/h
    def accelerer(self):
        if self.__type == "Course":
            Vehicule.accelerer(self)
            Vehicule.accelerer(self)
        else:
            Vehicule.accelerer(self)


class Moteur:

    __energie = ""

    def __init__(self, energie):
        if energie in ("Diesel", "Essence"):
            self.__energie = energie
        else:
            raise VehiculeException("Le type d'énergie est invalide.")

    def get_energie(self):
        return self.__energie







