
try:
    print("Début du try...")
    print("Division = {}".format(10 / 0))
    print("Fin du try...")
except NameError as e:
    print("Une erreur est survenue ! Code de gestion de l'erreur. Message : {}".format(e))
except ZeroDivisionError as e:
    print("Division par 0 ! Code de gestion de l'erreur. Message : {}".format(e))
except:
    print("Erreur inconnue...")

print("Suite de l'exécution du code.")
