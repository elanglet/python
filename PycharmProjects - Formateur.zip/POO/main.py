from parc.classes import Vehicule, Voiture, Velo
from parc.exceptions import VitesseException, CarburantException, VehiculeException

if __name__ == "__main__":
    try:
        # Création d'un objet Vehicule -> Instanciation
        #  veh1 : La variable référencant l'objet
        #  Vehicule() : Créée un nouvel objet, c'est le constructeur !
        veh1 = Vehicule("Citroen", "C4", 200, 180)

        # Accès aux attributs pour initialiser l'objet
        #
        # Inutile ! C'est le constructeur qui s'en charge !
        #
        # veh1.marque = "Citroen"
        # veh1.modele = "C4"
        # veh1.vitesse = 50
        # veh1.vitesse_max = 180

        # veh1.vitesse = -56

        print("{} {} roule à {} km/h".format(veh1.get_marque(), veh1.get_modele(), veh1.get_vitesse()))

        # Appel des méthodes
        veh1.accelerer()
        print("{} {} roule à {} km/h".format(veh1.get_marque(), veh1.get_modele(), veh1.get_vitesse()))

        veh1.freiner()
        print("{} {} roule à {} km/h".format(veh1.get_marque(), veh1.get_modele(), veh1.get_vitesse()))

        # veh1 = None
        # veh1.accelerer()
    except VitesseException as e:
        print("Erreur de vitesse : {}".format(e))
    except CarburantException as e:
        print("Erreur de carburant : {}".format(e))
    except VehiculeException as e:
        print("Erreur : {}".format(e))
    except Exception as e:
        print("Erreur inconnue : {}".format(e))

    try:
        print(" *** Les Voitures *** ")
        voit1 = Voiture("Peugeot", "308", 70, 200, 28, 40, 5, "Diesel")

        print("La {} {} possède un moteur {}".format(voit1.get_marque(), voit1.get_modele(), voit1.get_moteur().get_energie()))

        print("{} {} roule à {} km/h. Quantité de carburant : {}L".format(voit1.get_marque(), voit1.get_modele(), voit1.get_vitesse(), voit1.get_qte_carburant()))
        voit1.faire_le_plein()
        print("{} {} roule à {} km/h. Quantité de carburant : {}L".format(voit1.get_marque(), voit1.get_modele(), voit1.get_vitesse(), voit1.get_qte_carburant()))
        voit1.accelerer()
        voit1.accelerer()
        voit1.accelerer()
        voit1.accelerer()
        voit1.accelerer()
        voit1.accelerer()
        voit1.accelerer()
        voit1.accelerer()
        voit1.accelerer()
        voit1.accelerer()
        voit1.accelerer()
        print("{} {} roule à {} km/h. Quantité de carburant : {}L".format(voit1.get_marque(), voit1.get_modele(), voit1.get_vitesse(), voit1.get_qte_carburant()))
    except VitesseException as e:
        print("Erreur de vitesse : {}".format(e))
    except CarburantException as e:
        print("Erreur de carburant : {}".format(e))
    except VehiculeException as e:
        print("Erreur : {}".format(e))
    except Exception as e:
        print("Erreur inconnue : {}".format(e))

    try:
        print(" *** Les Vélos *** ")
        vel1 = Velo("Decathlon", "Rockrider", 10, 50, "VTT")

        print("{} {} roule à {} km/h. Type : {}".format(vel1.get_marque(), vel1.get_modele(), vel1.get_vitesse(), vel1.get_type()))
        vel1.accelerer()
        print("{} {} roule à {} km/h. Type : {}".format(vel1.get_marque(), vel1.get_modele(), vel1.get_vitesse(), vel1.get_type()))


        vel2 = Velo("Peugeot", "SuperCourse", 20, 60, "Toto")

        print("{} {} roule à {} km/h. Type : {}".format(vel2.get_marque(), vel2.get_modele(), vel2.get_vitesse(), vel2.get_type()))
        vel2.accelerer()
        print("{} {} roule à {} km/h. Type : {}".format(vel2.get_marque(), vel2.get_modele(), vel2.get_vitesse(), vel2.get_type()))
    except VitesseException as e:
        print("Erreur de vitesse : {}".format(e))
    except CarburantException as e:
        print("Erreur de carburant : {}".format(e))
    except VehiculeException as e:
        print("Erreur : {}".format(e))
    except Exception as e:
        print("Erreur inconnue : {}".format(e))

    try:
        print(" *** Tester le type des objets *** ")

        print("voit1 est une Voiture ? {}".format( isinstance(voit1, Voiture) ))
        print("voit1 est un Vehicule ? {}".format( isinstance(voit1, Vehicule) ))
        print("voit1 est un Velo ? {}".format( isinstance(voit1, Velo) ))

        entier = 1
        chaine = "1"

        print("Entier est un entier ? {}".format( isinstance(entier, int) ))
        print("Entier est une chaine ? {}".format( isinstance(entier, str) ))
        print("Chaine est un entier ? {}".format( isinstance(chaine, int) ))
        print("Chaine est une chaine ? {}".format( isinstance(chaine, str) ))
    except VitesseException as e:
        print("Erreur de vitesse : {}".format(e))
    except CarburantException as e:
        print("Erreur de carburant : {}".format(e))
    except VehiculeException as e:
        print("Erreur : {}".format(e))
    except Exception as e:
        print("Erreur inconnue : {}".format(e))

    try:
        print(" *** Comparaison des véhicules *** ")

        veh1 = Vehicule("Citroen", "C4", 50, 180)
        veh2 = Vehicule("Renault", "Mégane", 60, 220)
        veh3 = Vehicule("Citroen", "C4", 50, 180)

        print("veh1 == veh2 ? : {}".format(veh1 == veh2))
        print("veh1 == veh3 ? : {}".format(veh1 == veh3))
        print("veh2 == veh3 ? : {}".format(veh2 == veh3))
    except VitesseException as e:
        print("Erreur de vitesse : {}".format(e))
    except CarburantException as e:
        print("Erreur de carburant : {}".format(e))
    except VehiculeException as e:
        print("Erreur : {}".format(e))
    except Exception as e:
        print("Erreur inconnue : {}".format(e))


    try:
        print(" *** Comparaison des voitures *** ")

        voit1 = Voiture("Peugeot", "308", 70, 200, 28, 40, 5, "Diesel")
        voit2 = Voiture("Renault", "Mégane", 60, 220, 28, 40, 5, "Essence")
        voit3 = Voiture("Peugeot", "308", 70, 200, 28, 40, 5, "Diesel")

        print("voit1 == voit2 ? : {}".format(voit1 == voit2))
        print("voit1 == voit3 ? : {}".format(voit1 == voit3))
        print("voit2 == voit3 ? : {}".format(voit2 == voit3))
    except VitesseException as e:
        print("Erreur de vitesse : {}".format(e))
    except CarburantException as e:
        print("Erreur de carburant : {}".format(e))
    except VehiculeException as e:
        print("Erreur : {}".format(e))
    except Exception as e:
        print("Erreur inconnue : {}".format(e))
