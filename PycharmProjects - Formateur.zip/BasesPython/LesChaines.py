chaine = '''
Chaine de
caractères
sur plusieurs
lignes
'''

print(chaine)

produit = "livre"
prix = 29.90

print("Le prix du", produit, "est de", prix, "euros")

message = "Le prix du " + produit + " est de " + str(prix) + " euros"
print(message)

print(" *** Formattage historique en Python *** ")

message = "Le prix du %s est de %s euros" % (produit, prix)
print(message)

message = "Le prix du %(pro)s est de %(pri)s euros" % {"pro": produit, "pri": prix}
print(message)

print(" *** Formattage avec Python 3 *** ")

message = "Le prix du {} est de {} euros".format(produit, prix)
print(message)

message = "Le prix du {pro} est de {pri} euros".format(pro=produit, pri=prix)
print(message)

print(" *** Manipulation des chaines *** ")

une_chaine = "Ceci est une chaine de caractères"

longueur = len(une_chaine)
print("La chaine fait {} caractères".format(longueur))

print(une_chaine.upper())
print(une_chaine)

chaine_decoupee = une_chaine.split()
print(chaine_decoupee)

chaine_decoupee = une_chaine.split('a')
print(chaine_decoupee)

print("Est ce que 'de' est dans la chaine ? : {}".format("de" in une_chaine))

