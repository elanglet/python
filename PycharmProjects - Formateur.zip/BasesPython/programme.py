print("Hello World !")

# Déclaration de la variable a
a = 1

if a == 1:                      # Début du bloc 'if'
    print("A vaut bien 1")
    print("La condition est vérifiée")
else:                           # Début du bloc 'else'
    print("A ne vaut pas 1")
    print("La condition n'est pas vérifiée")

# Création de variables de différents types
entier = 25
print(type(entier))

reel = 23.36
print(type(reel))

chaine = "Chaine de caractères"
print(type(chaine))

booleen = True
print(type(booleen))


print("Changement de la valeur de 'entier'")
entier = "25"
print(type(entier))

print(" *** Les conditions *** ")

age = 54

# Si l'age est compris entre 18 et 60 ans...
if age >= 18 and age <= 60:
    print("L'age est compris entre 18 et 60 ans...")

if 18 <= age <= 60:
    print("L'age est compris entre 18 et 60 ans...")

print(" *** La fonction print *** ")

nom = "DUPONT"
age = 56

print("Monsieur", nom, "est agé de", age, "ans")

# Préciser un séparateur
print("Monsieur", nom, "est agé de", age, "ans", sep=';')

# Sortie d'erreur
import sys
print("Message d'erreur !", file=sys.stderr)