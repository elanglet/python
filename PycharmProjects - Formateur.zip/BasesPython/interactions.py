# On demande à l'utilisateur de saisir une première valeur
saisie1 = int( input("Veuillez saisir un premier nombre : ") )
print(type(saisie1))

# On demande à l'utilisateur de saisir une seconde valeur
saisie2 = int( input("Veuillez saisir un second nombre : ") )
print(type(saisie2))

somme = saisie1 + saisie2

print("La somme des deux nombres est : ", somme)

