from random import randint

nombre_a_deviner = randint(1, 100)

print("Le nombre à deviner est {}".format(nombre_a_deviner))

nombre_saisi = 0

# Tant que le nombre saisi et le nombre à deviner sont différents, on demande une saisie et on l'évalue
while nombre_saisi != nombre_a_deviner:

    nombre_saisi = int(input("Saisissez un nombre entre 1 et 99 : "))

    if nombre_saisi > nombre_a_deviner:
        print("Plus petit...")
    elif nombre_saisi < nombre_a_deviner:
        print("Plus grand...")

print("Bravo ! Vous avez trouvé !")

