dico = {
    "un": 1,
    "deux": 2,
    "trois": 3,
    "quatre": 4
}

print("Le dico : {}".format(dico))

print("L'élément à la clé 'deux' est {}".format(dico["deux"]))
print("L'élément à la clé 'deux' est {}".format(dico.get("deux")))

# Ajout d'une paire clé/valeur
dico["cinq"] = 5
print("Le dico : {}".format(dico))

# Suppression
del dico["trois"]
print("Le dico : {}".format(dico))

print("Parcours naturel du dictionnaire : ")
for cle in dico:
    print("{} = {}".format(cle, dico[cle]))

print("Autre parcours...")
# print(dico.items())
for cle, valeur in dico.items():
    print("{} = {}".format(cle, valeur))

# Exemple :
les_machines = [
    {"ip": "192.168.15.23", "port": 8080},
    {"ip": "10.0.0.2", "port": 5555},
    {"ip": "172.16.25.25", "port": 9090}
]

print(" *** URLs des machines *** ")
# Afficher les URLs http pour chaque machine sous la forme 'http://<ip>:<port>'
for machine in les_machines:
    print("http://{}:{}".format(machine["ip"], machine["port"]))
