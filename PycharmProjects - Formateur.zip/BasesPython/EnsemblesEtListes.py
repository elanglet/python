print(" *** Les ensembles *** ")

ensemble = ("un", "deux", "trois", "quatre")

print("Element à l'indice 1 : {}".format(ensemble[1]))

print("Elements entre l'indice 1 et 3 : {}".format(ensemble[1:3]))

print(" *** Les listes *** ")

liste = ["un", "deux", "trois", "quatre"]

print("Element à l'indice 1 : {}".format(liste[1]))

print("Elements entre l'indice 1 et 3 : {}".format(liste[1:3]))

liste[1] = "DEUX"

print(liste)

print("Ajouter une valeur à la fin")
liste.append("cinq")
print(liste)

print("Inserer une valeur")
liste.insert(0, "zero")
print(liste)

print("Fusionner des listes")
autre_liste = ["six", "sept", "huit"]
liste.extend(autre_liste)
print(liste)

print("Supprimer à partir de l'indice")
del liste[2]
print(liste)

print("Supprimer à partir de la valeur")
liste.remove("cinq")
print(liste)

print("Parcours de la liste : ")

for element in liste:
    print(element)
